from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv(
    "DATABASE_URL", 
    "sqlite+aiosqlite:///./shopira.db"
)

# موتور دیتابیس
engine = create_async_engine(
    DATABASE_URL,
    echo=True,           # برای توسعه (در production خاموش کن)
    pool_pre_ping=True
)

# سشن async
async_session = sessionmaker(
    engine, 
    class_=AsyncSession, 
    expire_on_commit=False
)


async def get_db():
    """تابع کمکی برای گرفتن سشن دیتابیس"""
    async with async_session() as session:
        yield session


async def init_db():
    """ایجاد تمام جداول"""
    from database.models import Base
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Database tables created successfully")


async def check_connection():
    """بررسی اتصال به دیتابیس"""
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False
